﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveMonster : MonoBehaviour {
    private bool enChasse;
    private bool retourOrigin;
    public bool etourdi;
    private float direction;
    private float previousPosZ;
    private float deltaT;
    
    

    [SerializeField]
    GameObject door;

    [SerializeField]
    GameObject cible;

    [SerializeField]
    float TimeMax;

    private Vector3 posOriginal;
	// Use this for initialization
	void Start () {
        posOriginal = transform.position;
        enChasse = false;
        etourdi = false;
        retourOrigin = false;
        deltaT = 0.0f;
	}
	
	// Update is called once per frame
	void Update () {
        if (!etourdi)
        {
            SeekPlayer();
            Move();
            Flip();
        }
        else {
            transform.Find("Etourdi").gameObject.SetActive(true);
            deltaT += Time.deltaTime;
            if(deltaT > TimeMax)
            {
                deltaT = 0.0f;
                etourdi = false;
                transform.Find("Etourdi").gameObject.SetActive(false);
            }
        }


    }
    void Move() {
        if (!enChasse && !retourOrigin)
        {
            deltaT += 0.02f;
            direction = posOriginal.z + Mathf.PingPong(deltaT, length: 2)-previousPosZ;
            previousPosZ = posOriginal.z + Mathf.PingPong(deltaT, length: 2);
            transform.position = new Vector3(posOriginal.x, posOriginal.y, posOriginal.z + Mathf.PingPong(deltaT, length: 2));
        }else if(enChasse){
            direction = (cible.transform.position.z - previousPosZ)/ Mathf.Abs(cible.transform.position.z - previousPosZ) *0.03f;
            previousPosZ = previousPosZ + (cible.transform.position.z - previousPosZ) / Mathf.Abs(cible.transform.position.z - previousPosZ) * 0.03f;
            transform.position = new Vector3(posOriginal.x, posOriginal.y, previousPosZ + (cible.transform.position.z - previousPosZ) / Mathf.Abs(cible.transform.position.z - previousPosZ) * 0.03f);
        }else if(retourOrigin)
        {
            direction = (posOriginal.z - previousPosZ) /Mathf.Abs((posOriginal.z - previousPosZ)) *0.02f;
            previousPosZ = previousPosZ + (posOriginal.z - previousPosZ) / Mathf.Abs((posOriginal.z - previousPosZ)) * 0.02f;
            transform.position = new Vector3(posOriginal.x, posOriginal.y, previousPosZ + (posOriginal.z - previousPosZ) / Mathf.Abs((posOriginal.z - previousPosZ)) * 0.02f);
            if (Mathf.Abs(posOriginal.z - previousPosZ) < 0.1f)
            {
                retourOrigin = false;
            }
        }
    }

    void Flip()
    {
        if(direction < 0)
        {
            transform.rotation = new Quaternion(0.0f, 180f, 0.0f, 1.0f);
        }
        else
        {
            transform.rotation = new Quaternion(0.0f, 0.0f, 0.0f, 1.0f);
        }
    }

    void SeekPlayer() {
        if (cible.transform.position.z - posOriginal.z < 6.0 
            && cible.transform.position.z - posOriginal.z > -1 
            && Mathf.Abs(cible.transform.position.y - posOriginal.y)<0.5)
        {
            enChasse = true;
            deltaT = 0.0f;
        }else if (enChasse)
        {
            enChasse = false;
            retourOrigin = true;
        }
        else
        {
            enChasse = false;
        }
    }

    void OnTriggerEnter(Collider coll)
    {
        print(coll.gameObject.tag);
        if (coll.gameObject.tag == "Plaque")
        {
            print("OK");
            door.SetActive(false);
        }
    }

    void OnTriggerExit(Collider coll)
    {
        if (coll.gameObject.tag == "Plaque")
        {
            door.SetActive(true);
        }
    }
}
